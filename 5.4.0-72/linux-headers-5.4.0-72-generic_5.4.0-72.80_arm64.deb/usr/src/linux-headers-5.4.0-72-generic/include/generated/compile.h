/* This file is auto generated, version 80 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#80 SMP Mon Apr 26 17:52:00 UTC 2021"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "739aceafbdf3"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-17ubuntu1~20.04)"
