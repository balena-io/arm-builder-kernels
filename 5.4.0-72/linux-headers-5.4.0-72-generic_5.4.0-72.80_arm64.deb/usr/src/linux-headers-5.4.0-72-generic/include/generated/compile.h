/* This file is auto generated, version 80 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#80 SMP Mon Apr 26 18:44:11 UTC 2021"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "34dc307e361b"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-17ubuntu1~20.04)"
