#define UTS_RELEASE "4.15.0-45-generic"
#define UTS_UBUNTU_RELEASE_ABI 45
