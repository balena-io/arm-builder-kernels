/* This file is auto generated, version 48~16.04.1 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#48~16.04.1 SMP Fri Feb 8 10:38:11 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "arm02.builders.resin.io"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu/Linaro 5.4.0-6ubuntu1~16.04.11)"
